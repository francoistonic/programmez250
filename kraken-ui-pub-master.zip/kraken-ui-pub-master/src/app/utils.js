export const BASE = 'https://api.themoviedb.org/3'
export const API_KEY = '' // change to add your own api key
export const SESSION_ID = '' // change to add your own sessionid
export const ACCOUNT_ID = 'Toto' // change to add your own accoundid