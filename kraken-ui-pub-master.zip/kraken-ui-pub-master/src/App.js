
import Router from '../src/app/router'

const App = () => {
  return <Router />
}

export default App
