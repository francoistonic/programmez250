# kata-technical-workshop
Our personal kata to train on legacy code notions as Seams, characterization tests and golden master
