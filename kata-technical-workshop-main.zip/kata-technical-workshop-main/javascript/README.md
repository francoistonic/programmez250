# CodeWorks code trivia kata
CodeWorks version of the ugly trivia kata

## Installation des dépendances du projet
```
npm install
```

## Lancement des tests de l'édition en cours
[Jest, test runner](https://jestjs.io/docs/en/getting-started.html)
```
npm run test
```