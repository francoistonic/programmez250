const runCodeTest = require('./codeTestRunner.js');

runCodeTest()
process.exit()
